## RiseOfSerpentard 



## Collaborate with your team

- R*****
- L****
- C*****


## Name - synopsis

Il s'agit d'une version plus avancé du celebre jeu Snake, et qui s'inspire de l'univers d'Harry Potte. Le serpent est un Basilic qui se deplace dans une galerie, et qui chasse des sorciers, ne doit pas toucher les murs de la galerie et doit eviter les sorciers de la maison Serpentard.



## Integrate with your tools

- Le code source du projet est en C++ et pour l'affichage graphique, nous avons utiliser l'outil SDL.


## Installation

# sur linux:

Il faut au préalable taper la commande make @default. Celle-ci créera les repertoires obj/txt obj/core obj/sdl bin dans lesquels nous retrouverons par la suite les fichier objets (.o) et les executables. 
Une fois fait, il faut taper la comande make, qui lancera la compilation et la creation des éxecutables: 
- bin/jeu_txt qui est un affichage txt du jeu
- bin/jeu_sdl qui est un affichage graphique du jeu
- bin/test qui effectue les test de regressions des classes se trouvant dans le repertoire src/core
Pour afficher les executables, il faut taper  respectivement les commandes suivantes:
- bin/jeu_txt 
- bin/jeu_sdl
- bin/test
Pour affiche la documentation, il faut taper la commande make -B doc, qui lancera celle-ci ouvrira une page html sur firefox contenat la documentation des differentes classes
Pour effacer les fichier objet et les executables, il faut tapper respectivement les commandes make clean et make veryclean.
Pour effacer la docuementation, il faut taper la commande make cleandoc

# sur windows

il faut verifier que le navigateur firefox y est installer. Il faut egalement qu'un terminale wsl y soit installé.
Si ce n'est pas le cas, il faudra tapper dans un terminal shell les commandes suivantes:
- wsl --set-default-version 2               # définir la version 2 par défaut pour la prochaine installation
- wsl -l -v                                 # afficher les versions
- wsl --list --verbose                      # afficher les versions
- wsl --set-version <votre ditribution> 2   # Convertir la distribution <votre distribution> en version 2
Une fois fait, il faudra tapper les même comandes que sur linux dans un terminal wsl.


## Organistaion

le jeu contient répertoires:
- bin : qui contient les executable
- obj : qui contient les fichier objet, rangés dans les sous répertoire core, txt et sdl
- src : qui contient les code sources, rangés dans les sous répertoire core, txt et sdl
- datta : qui contient les image de notre jeu 
- doc : qui contient la documentation, ainsi que les slides de notre présentation/soutenace
- extern : qui contient la bibliotheque sdl necessaire a l'affichage graphique 

le jeu contient egalement un makefile qui permet la compilation.


## Usage 

Réaliser dans le cadre d'un projet pour l'UE LIFAPCDA.


## Licence 

 réalisé par Ramdane AMAOUZ p2002623, Lylia DAOUDI p2105694, Cyrine BOUDJELEL p2103034