#include <cassert>
#include <time.h>
#include "sdlJeu.h"
#include <stdlib.h>

#include <chrono>   
#include <cstdlib>    
#include <unistd.h>
#include <string.h>

#include <iostream>
using namespace std;
using namespace std::chrono;

const int TAILLE_SPRITE = 15;

float temps () {
    return float(SDL_GetTicks()) / (CLOCKS_PER_SEC);  // conversion des ms en secondes en divisant par 1000
}

// ============= CLASS IMAGE =============== //

Image::Image () : m_surface(nullptr), m_texture(nullptr), m_hasChanged(false) {
}

Image::~Image()
{
    SDL_FreeSurface(m_surface);
    SDL_DestroyTexture(m_texture);

    m_surface = nullptr;
    m_texture = nullptr;
    m_hasChanged = false;
}

void Image::loadFromFile (const char* filename, SDL_Renderer * renderer) {
    m_surface = IMG_Load(filename);
    if (m_surface == nullptr) {
        string nfn = string("../") + filename;
        cout << "Error: cannot load "<< filename <<". Trying "<<nfn<<endl;
        m_surface = IMG_Load(nfn.c_str());
        if (m_surface == nullptr) {
            nfn = string("../") + nfn;
            m_surface = IMG_Load(nfn.c_str());
        }
    }
    if (m_surface == nullptr) {
        cout<<"Error: cannot load "<< filename <<endl;
        SDL_Quit();
        exit(1);
    }

    SDL_Surface * surfaceCorrectPixelFormat = SDL_ConvertSurfaceFormat(m_surface,SDL_PIXELFORMAT_ARGB8888,0);
    SDL_FreeSurface(m_surface);
    m_surface = surfaceCorrectPixelFormat;

    //m_texture = SDL_CreateTextureFromSurface(renderer,surfaceCorrectPixelFormat);
    m_texture = SDL_CreateTextureFromSurface(renderer, surfaceCorrectPixelFormat);

    
    if (m_texture == NULL) {
        cout << "Error: problem to create the texture of "<< filename<< endl;
        SDL_Quit();
        exit(1);
    }
}

void Image::loadFromCurrentSurface (SDL_Renderer * renderer) {
    m_texture = SDL_CreateTextureFromSurface(renderer,m_surface);
    if (m_texture == nullptr) {
        cout << "Error: problem to create the texture from surface " << endl;
        SDL_Quit();
        exit(1);
    }
}

void Image::draw (SDL_Renderer * renderer, int x, int y, int w, int h) {
    int ok;
    SDL_Rect r;
    r.x = x;
    r.y = y;
    r.w = (w<0)?m_surface->w:w;
    r.h = (h<0)?m_surface->h:h;

    if (m_hasChanged) {
        ok = SDL_UpdateTexture(m_texture,nullptr,m_surface->pixels,m_surface->pitch);
        assert(ok == 0);
        m_hasChanged = false;
    }

    ok = SDL_RenderCopy(renderer,m_texture,nullptr,&r);
    assert(ok == 0);
}

SDL_Texture * Image::getTexture() const {return m_texture;}

void Image::setSurface(SDL_Surface * surf) {m_surface = surf;}






// ============= CLASS SDLJEU =============== //

SDLSimple::SDLSimple () : jeu() {

//============================================================================


    int dimx, dimy;
	dimx = jeu.getConstGalerie().getLargeur();   
	dimy = jeu.getConstGalerie().getHauteur();   
	dimx = dimx * TAILLE_SPRITE;
	dimy = dimy * TAILLE_SPRITE;


// Initialisation de la SDL
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        cout << "Erreur lors de l'initialisation de la SDL : " << SDL_GetError() << endl;
        SDL_Quit();
        exit(1);
    }

    // Création de la fenêtre avec le rendu accéléré
    window = SDL_CreateWindow("Rise of Serpentard", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, dimx, dimy, SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE);
    if (window == nullptr) {
        cout << "Erreur lors de la creation de la fenetre : " << SDL_GetError() << endl; 
        SDL_Quit(); 
        exit(1);
    }

    // Création du renderer avec le rendu accéléré
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if (renderer == nullptr) {
        cout << "Erreur lors de la creation du renderer : " << SDL_GetError() << endl; 
        SDL_DestroyWindow(window);
        SDL_Quit(); 
        exit(1);
    }

    // Initialisation de SDL_image
    int imgFlags = IMG_INIT_PNG | IMG_INIT_JPG;
    if (!(IMG_Init(imgFlags) & imgFlags)) {
        cout << "SDL_image could not initialize! SDL_image Error: " << IMG_GetError() << endl;
        SDL_DestroyRenderer(renderer);
        SDL_DestroyWindow(window);
        SDL_Quit();
        exit(1);
    }

    // Initialisation de SDL_ttf
    if (TTF_Init() != 0) {
        cout << "Erreur lors de l'initialisation de la SDL_ttf : " << TTF_GetError() << endl;
        SDL_DestroyRenderer(renderer);
        SDL_DestroyWindow(window);
        IMG_Quit();
        SDL_Quit();
        exit(1);
    }

    // Initialisation de SDL_mixer pour le son
    if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0) {
        cout << "SDL_mixer could not initialize! SDL_mixer Error: " << Mix_GetError() << endl;
        cout << "No sound !!!" << endl;
        withSound = false;
    } else {
        withSound = true;
    }

    if (!loadRessources()) {
        cerr << "Failed to load resources!" << endl;
        cleanup();
        exit(1);
    }

}


bool SDLSimple::loadRessources(){


    im_mur.loadFromFile("data/mur.png", renderer);

    ecran.loadFromFile("data/ecran.png", renderer);

    im_sorcier1.loadFromFile("data/sorcier1.png", renderer);
    im_sorcier2.loadFromFile("data/sorcier2.png", renderer);
    im_sorcier3.loadFromFile("data/sorcier3.png", renderer);
    im_sorcier4.loadFromFile("data/sorcier4.png", renderer);
    im_sorcier5.loadFromFile("data/sorcier4.png", renderer);
    im_sorcier6.loadFromFile("data/sorcier4.png", renderer);
    im_sorcier7.loadFromFile("data/sorcier4.png", renderer);
    im_sorcier8.loadFromFile("data/sorcier4.png", renderer);

    im_basilc.loadFromFile("data/vert1.png", renderer);

    im_pillule1.loadFromFile("data/pillule1.png", renderer);
    im_pillule2.loadFromFile("data/pillule2.png", renderer);
    im_pillule3.loadFromFile("data/pillule3.png", renderer);
    im_pillule4.loadFromFile("data/pillule4.png", renderer);

    // Charger la police
    font = TTF_OpenFont("data/DejaVuSansCondensed.ttf", 50);
    if (!font) {
        font = TTF_OpenFont("../data/DejaVuSansCondensed.ttf", 50);
        if (!font) {
            cerr << "Failed to load DejaVuSansCondensed.ttf! SDL_TTF Error: " << TTF_GetError() << endl;
            return false;
        }
    }

    font_color1.r = 0; font_color1.g = 0; font_color1.b = 0; 
    font_im.setSurface(TTF_RenderText_Solid(font, "-- Appuie sur la touche Entrer --", font_color1));
    font_im.loadFromCurrentSurface(renderer);

    font_color2.r = 255; font_color2.g = 255; font_color2.b = 255;

    font_im1.setSurface(TTF_RenderText_Solid(font, "Score : ", font_color2));
    font_im1.loadFromCurrentSurface(renderer);

    font_im2.setSurface(TTF_RenderText_Solid(font, "Niveau : ", font_color2));
    font_im2.loadFromCurrentSurface(renderer);

    font_color3.r = 0; font_color3.g = 100; font_color3.b = 0;

    font_im3.setSurface(TTF_RenderText_Solid(font, "Le mal est libere! La maison Serpentard est sur le point de renaitre!", font_color3));
    font_im3.loadFromCurrentSurface(renderer);

    font_im4.setSurface(TTF_RenderText_Solid(font, "Le basilic est resuisite et a soif de sang! Oh, mais que vois-je, les autres maisons qui se mobilisent pour tenter ", font_color3));
    font_im4.loadFromCurrentSurface(renderer);

    font_im5.setSurface(TTF_RenderText_Solid(font, "de le stopper. Hahaha! Ils vont servir de casse-croute!", font_color3));
    font_im5.loadFromCurrentSurface(renderer);

    font_im6.setSurface(TTF_RenderText_Solid(font, "Dans ce jeu, tu incarne le basilic, et ton but est d'accumuler des points en mangeant le plus de sorciers possible.", font_color3));
    font_im6.loadFromCurrentSurface(renderer);

    font_im7.setSurface(TTF_RenderText_Solid(font, "Mais tous les sorciers n'ont pas la meme valeur nutritive :", font_color3));
    font_im7.loadFromCurrentSurface(renderer);

    font_im8.setSurface(TTF_RenderText_Solid(font, "- un sorcier de la maison Griffon-d'or te rapporte 5 points", font_color3));
    font_im8.loadFromCurrentSurface(renderer);

    font_im9.setSurface(TTF_RenderText_Solid(font, "- un sorcier de la maison Sert-d'aigle te rapporte 3 points", font_color3));
    font_im9.loadFromCurrentSurface(renderer);

    font_im10.setSurface(TTF_RenderText_Solid(font, "- un sorcier de la maison Pouffe-souffle te rapporte 1 point", font_color3));
    font_im10.loadFromCurrentSurface(renderer);

    font_im11.setSurface(TTF_RenderText_Solid(font, "Mais un sorcier de la maison Serpentard n'est pas commestible ne te rappote rien. Ca ne se fait pas de manger ses", font_color3));
    font_im11.loadFromCurrentSurface(renderer);

    font_im12.setSurface(TTF_RenderText_Solid(font, "allies!", font_color3));
    font_im12.loadFromCurrentSurface(renderer);


    font_color4.r = 0; font_color4.g = 100; font_color4.b =100;  
    font_color5.r = 200; font_color5.g = 200; font_color5.b = 0;
    font_color6.r = 200; font_color6.g = 0; font_color6.b = 0;

    font_im13.setSurface(TTF_RenderText_Solid(font, "pouffe-souffle", font_color4));
    font_im13.loadFromCurrentSurface(renderer);

    font_im14.setSurface(TTF_RenderText_Solid(font, "serre-d'aigle", font_color5));
    font_im14.loadFromCurrentSurface(renderer);

    font_im15.setSurface(TTF_RenderText_Solid(font, "griffon-d'or", font_color6));
    font_im15.loadFromCurrentSurface(renderer);

    font_im16.setSurface(TTF_RenderText_Solid(font, "serpentard", font_color3));
    font_im16.loadFromCurrentSurface(renderer);

    font_im17.setSurface(TTF_RenderText_Solid(font, "appuie sur ESPACE pour jouer", font_color3));
    font_im17.loadFromCurrentSurface(renderer);

    font_im18.setSurface(TTF_RenderText_Solid(font, "tu t'es pris un mur!", font_color3));
    font_im18.loadFromCurrentSurface(renderer);

    font_im19.setSurface(TTF_RenderText_Solid(font, "alors comme ca on mange ses allies?", font_color3));
    font_im19.loadFromCurrentSurface(renderer);

    font_im20.setSurface(TTF_RenderText_Solid(font, "Perdu!", font_color6));
    font_im20.loadFromCurrentSurface(renderer);

    font_im21.setSurface(TTF_RenderText_Solid(font, "R : rejouer", font_color6));
    font_im21.loadFromCurrentSurface(renderer);

    font_im22.setSurface(TTF_RenderText_Solid(font, "ESC : quitter", font_color6));
    font_im22.loadFromCurrentSurface(renderer);

    // SONS
    if (withSound) {
        sound = Mix_LoadWAV("data/harry_potter_song.mp3");
        if (!sound) {
            sound = Mix_LoadWAV("../data/harry_potter_song.mp3");
            if (!sound) {
                cerr << "Failed to load son.wav! SDL_mixer Error: " << Mix_GetError() << endl;
                return false;
            }
        }
    }

    return true;
}

SDLSimple::~SDLSimple() {

    cleanup();

    if (withSound) Mix_Quit();
    TTF_CloseFont(font);
    TTF_Quit();
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
}


void SDLSimple::Score() {
    // Charger la police
    TTF_Font* font = TTF_OpenFont("data/DejaVuSansCondensed.ttf", 18);
    if (!font) {
        std::cerr << "Failed to load DejaVuSansCondensed.ttf! SDL_TTF Error: " << TTF_GetError() << std::endl;
        SDL_Quit();
        exit(1);
    }

    // Créer la surface de texte
    SDL_Color textColor = {255, 255, 255, 255};
    char scoreText[32];
    snprintf(scoreText, sizeof(scoreText), "%d", jeu.getscore());
    SDL_Surface* textSurface = TTF_RenderText_Blended(font, scoreText, textColor);
    if (!textSurface) {
        std::cerr << "Failed to render text surface! SDL_TTF Error: " << TTF_GetError() << std::endl;
        TTF_CloseFont(font);
        SDL_Quit();
        exit(1);
    }

    // Créer la texture à partir de la surface de texte
    SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, textSurface);
    if (!texture) {
        std::cerr << "Failed to create texture from surface! SDL Error: " << SDL_GetError() << std::endl;
        SDL_FreeSurface(textSurface);
        TTF_CloseFont(font);
        SDL_Quit();
        exit(1);
    }

    // Libérer la surface de texte
    SDL_FreeSurface(textSurface);
    TTF_CloseFont(font);

    // Dessiner la texture sur le renderer
    SDL_Rect renderQuad = {1342, 100, 30, 30};
    SDL_RenderCopy(renderer, texture, nullptr, &renderQuad);

    // Libérer la texture
    SDL_DestroyTexture(texture);
}




void SDLSimple::Niveau(){
    if (TTF_Init() < 0)
    {
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "[DEBUG] > %s", TTF_GetError());
    }
    TTF_Font* font = TTF_OpenFont("data/DejaVuSansCondensed.ttf", 18); 

    if (font == nullptr)
    {
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "[DEBUG] > %s", TTF_GetError());

    }
    SDL_Color a;
	a.a = 255;
	a.b = 255;
	a.g = 255;
	a.r = 255;

    
    
    char niveau1[3];
    sprintf(niveau1,"%d",jeu.getniveau() );
    const char* niveau = niveau1;
    
    SDL_Surface* text = TTF_RenderText_Blended(font,niveau, a); // Crée un surface qui contient le texte

    SDL_Texture* texture1 = SDL_CreateTextureFromSurface(renderer, text);

    SDL_Rect position1;
    SDL_QueryTexture(texture1, nullptr, nullptr, &position1.w, &position1.h); // Récupere la dimension de la texture
    
    // Centre la texture sur l'écran
    position1.x = 1342;
    position1.y = 250;
    position1.h = 30;
    position1.w = 30;
    //SDL_FreeSurface(text);
    SDL_FreeSurface(text);
    TTF_CloseFont(font);

	
         
    //SDL_RenderCopy(renderer, texture, nullptr, &position);
    SDL_RenderCopy(renderer, texture1, nullptr, &position1);
    SDL_DestroyTexture(texture1);
}

void SDLSimple::home(){
    Image ecran;
    ecran.loadFromFile("data/serpentard.png",renderer);
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
    SDL_RenderClear(renderer);
    ecran.draw(renderer,0,10,1470,750);

    SDL_Rect home ;
    home.x = 370;  home.y= 710; home.w = 685.4; home.h = 20;
    SDL_RenderCopy(renderer,font_im.getTexture(),nullptr,&home);

    SDL_RenderPresent(renderer);
}


void SDLSimple::cleanup() {
    // Libérer les ressources audio si elles ont été chargées
    if (withSound) {
        Mix_CloseAudio();
    }

    // Libérer le rendu s'il a été initialisé
    if (renderer) {
        SDL_DestroyRenderer(renderer);
        renderer = nullptr;
    }

    // Libérer la fenêtre SDL si elle a été initialisée
    if (window) {
        SDL_DestroyWindow(window);
        //window = nullptr;
    }


    // Libérer les textures et surfaces chargées
    //im_mur.cleanup();
    // Libérer d'autres textures et surfaces le cas échéant

    // Libérer les ressources audio chargées avec SDL_mixer
    // Si vous avez chargé des sons, vous devez les libérer ici

    // Nettoyer et quitter les sous-systèmes SDL
    Mix_Quit();
    TTF_Quit();
    IMG_Quit();
    SDL_Quit();
}


void SDLSimple::Synopsis() {

    //Image ecran;
    SDL_SetRenderDrawColor(renderer, 50, 50, 50, 0);
    SDL_RenderClear(renderer);
    //ecran.draw(renderer,0,10,1470,750);
    SDL_Rect ligne1 ;
    ligne1.x = 10;  ligne1.y= 10; ligne1.w = 962.5; ligne1.h = 50;
    SDL_RenderCopy(renderer,font_im3.getTexture(),nullptr,&ligne1);
   // SDL_RenderPresent(renderer);

    SDL_Rect ligne2 ;
    ligne2.x = 10;  ligne2.y= 60; ligne2.w = 1400; ligne2.h = 50;   //une largeur de 1400 pour 96 caracteres
    SDL_RenderCopy(renderer,font_im4.getTexture(),nullptr,&ligne2);

    SDL_Rect ligne3 ;
    ligne3.x = 10;  ligne3.y= 110; ligne3.w = 685.4; ligne3.h = 50;
    SDL_RenderCopy(renderer,font_im5.getTexture(),nullptr,&ligne3);

    SDL_Rect ligne4 ;
    ligne4.x = 10;  ligne4.y= 160; ligne4.w = 1210.4; ligne4.h = 50;
    SDL_RenderCopy(renderer,font_im6.getTexture(),nullptr,&ligne4);
    
    SDL_Rect ligne5 ;
    ligne5.x = 10;  ligne5.y= 210; ligne5.w = 743.7; ligne5.h = 50;
    SDL_RenderCopy(renderer,font_im7.getTexture(),nullptr,&ligne5);

    SDL_Rect ligne6 ;
    ligne6.x = 10;  ligne6.y= 260; ligne6.w = 962.5; ligne6.h = 50;
    SDL_RenderCopy(renderer,font_im8.getTexture(),nullptr,&ligne6);

    SDL_Rect ligne7 ;
    ligne7.x = 10;  ligne7.y= 310; ligne7.w = 1004.25; ligne7.h = 50;
    SDL_RenderCopy(renderer,font_im9.getTexture(),nullptr,&ligne7);

    SDL_Rect ligne8 ;
    ligne8.x = 10;  ligne8.y= 360; ligne8.w = 1018; ligne8.h = 50;
    SDL_RenderCopy(renderer,font_im10.getTexture(),nullptr,&ligne8);

    SDL_Rect ligne9 ;
    ligne9.x = 10;  ligne9.y= 410; ligne9.w = 1355.25; ligne9.h = 50;
    SDL_RenderCopy(renderer,font_im11.getTexture(),nullptr,&ligne9);

    SDL_Rect ligne10 ;
    ligne10.x = 10;  ligne10.y= 460; ligne10.w = 114; ligne10.h = 50;
    SDL_RenderCopy(renderer,font_im12.getTexture(),nullptr,&ligne10);

    im_sorcier1.draw(renderer,350,550,60,60);
    im_sorcier2.draw(renderer,550,550,60,60);
    im_sorcier3.draw(renderer,750,550,60,60);
    im_sorcier4.draw(renderer,950,550,60,60);

    SDL_Rect ligne11 ;
    ligne11.x = 330;  ligne11.y= 610; ligne11.w = 114; ligne11.h = 30;
    SDL_RenderCopy(renderer,font_im13.getTexture(),nullptr,&ligne11);

    SDL_Rect ligne12 ;
    ligne12.x = 530;  ligne12.y= 610; ligne12.w = 114; ligne12.h = 30;
    SDL_RenderCopy(renderer,font_im14.getTexture(),nullptr,&ligne12);

    SDL_Rect ligne13 ;
    ligne13.x = 730;  ligne13.y= 610; ligne13.w = 114; ligne13.h = 30;
    SDL_RenderCopy(renderer,font_im15.getTexture(),nullptr,&ligne13);

    SDL_Rect ligne14 ;
    ligne14.x = 930;  ligne14.y= 610; ligne14.w = 114; ligne14.h = 30;
    SDL_RenderCopy(renderer,font_im16.getTexture(),nullptr,&ligne14);

    SDL_Rect ligne15 ;
    ligne15.x = 1030;  ligne15.y= 710; ligne15.w = 314; ligne15.h = 30;
    SDL_RenderCopy(renderer,font_im17.getTexture(),nullptr,&ligne15);

    SDL_RenderPresent(renderer);
}



void SDLSimple::sdlAff () {
	//Remplir l'écran de noir
    SDL_SetRenderDrawColor(renderer, 50, 50, 50, 0);
    SDL_RenderClear(renderer);

	unsigned int x,y;
	const Galerie& gal = jeu.getConstGalerie();
    
	const Basilic& bas = jeu.getConstBasilic();

	const Sorcier& sor1 = jeu.getConstSorc1();
    const Sorcier& sor2 = jeu.getConstSorc2();
    const Sorcier& sor3 = jeu.getConstSorc3();
    const Sorcier& sor4 = jeu.getConstSorc4();

    const Sorcier& sor5 = jeu.getConstSorc5();
    const Sorcier& sor6 = jeu.getConstSorc6();
    const Sorcier& sor7 = jeu.getConstSorc7();
    const Sorcier& sor8 = jeu.getConstSorc8();

    const PiluleM& pil1 = jeu.getConstPilule1();
    const PiluleM& pil2 = jeu.getConstPilule2();
    const PiluleM& pil3 = jeu.getConstPilule3();
    const PiluleM& pil4 = jeu.getConstPilule4();


    // Afficher les sprites des murs et des pastilles
	for (x=0;x<gal.getLargeur()   ;++x)
		for (y=0;y<gal.getHauteur();++y)
			if (gal.getXY(x,y)=='#')
				im_mur.draw(renderer,x*TAILLE_SPRITE,y*TAILLE_SPRITE,TAILLE_SPRITE,TAILLE_SPRITE);
    


	// Afficher le sprite du sorcier
	im_sorcier1.draw(renderer,sor1.getPosX()*TAILLE_SPRITE,sor1.getPosY()*TAILLE_SPRITE,TAILLE_SPRITE,TAILLE_SPRITE);
    im_sorcier2.draw(renderer,sor2.getPosX()*TAILLE_SPRITE,sor2.getPosY()*TAILLE_SPRITE,TAILLE_SPRITE,TAILLE_SPRITE);
    im_sorcier3.draw(renderer,sor3.getPosX()*TAILLE_SPRITE,sor3.getPosY()*TAILLE_SPRITE,TAILLE_SPRITE,TAILLE_SPRITE);
    im_sorcier4.draw(renderer,sor4.getPosX()*TAILLE_SPRITE,sor4.getPosY()*TAILLE_SPRITE,TAILLE_SPRITE,TAILLE_SPRITE);

    im_sorcier5.draw(renderer,sor5.getPosX()*TAILLE_SPRITE,sor5.getPosY()*TAILLE_SPRITE,TAILLE_SPRITE,TAILLE_SPRITE);
    im_sorcier6.draw(renderer,sor6.getPosX()*TAILLE_SPRITE,sor6.getPosY()*TAILLE_SPRITE,TAILLE_SPRITE,TAILLE_SPRITE);
    im_sorcier7.draw(renderer,sor7.getPosX()*TAILLE_SPRITE,sor7.getPosY()*TAILLE_SPRITE,TAILLE_SPRITE,TAILLE_SPRITE);
    im_sorcier8.draw(renderer,sor8.getPosX()*TAILLE_SPRITE,sor8.getPosY()*TAILLE_SPRITE,TAILLE_SPRITE,TAILLE_SPRITE);

    //aficher le sprite du basilic
    for(unsigned int i=0; i<bas.corp.getT();i++){
        im_basilc.draw(renderer, bas.corp.getvaleur(i).x*TAILLE_SPRITE, bas.corp.getvaleur(i).y*TAILLE_SPRITE, TAILLE_SPRITE, TAILLE_SPRITE);
    }



    //afficher les sprite des pillules
    im_pillule1.draw(renderer, pil1.getX()*TAILLE_SPRITE, pil1.getY()*TAILLE_SPRITE, TAILLE_SPRITE, TAILLE_SPRITE);
    im_pillule2.draw(renderer, pil2.getX()*TAILLE_SPRITE, pil2.getY()*TAILLE_SPRITE, TAILLE_SPRITE, TAILLE_SPRITE);
    im_pillule3.draw(renderer, pil3.getX()*TAILLE_SPRITE, pil3.getY()*TAILLE_SPRITE, TAILLE_SPRITE, TAILLE_SPRITE);
    im_pillule4.draw(renderer, pil4.getX()*TAILLE_SPRITE, pil4.getY()*TAILLE_SPRITE, TAILLE_SPRITE, TAILLE_SPRITE);


    SDL_Rect positionScore;
    positionScore.x = 1342; positionScore.y = 25; positionScore.w = 107; positionScore.h = 30;
    SDL_RenderCopy(renderer,font_im1.getTexture(),nullptr,&positionScore);

    SDL_Rect positionNiveau;
    positionNiveau.x = 1340; positionNiveau.y = 175; positionNiveau.w = 110; positionNiveau.h = 30;
    SDL_RenderCopy(renderer,font_im2.getTexture(),nullptr,&positionNiveau);

    if (jeu.getMur() == true ){ 
        ecran.draw(renderer,420,270,400,150);

        SDL_Rect tab ;
        tab.x = 480;  tab.y= 330; tab.w = 285.4; tab.h = 20;
        SDL_RenderCopy(renderer,font_im18.getTexture(),nullptr,&tab);

        SDL_Rect tab1 ;
        tab1.x = 580;  tab1.y= 270; tab1.w = 70.4; tab1.h = 60;
        SDL_RenderCopy(renderer,font_im20.getTexture(),nullptr,&tab1);

        SDL_Rect tab2 ;
        tab2.x = 520;  tab2.y= 370; tab2.w = 70.4; tab2.h = 20;
        SDL_RenderCopy(renderer,font_im21.getTexture(),nullptr,&tab2);

        SDL_Rect tab3 ;
        tab3.x = 650;  tab3.y= 370; tab3.w = 70.4; tab3.h = 20;
        SDL_RenderCopy(renderer,font_im22.getTexture(),nullptr,&tab3);
    }

    if (jeu.getCsc() == true ){ 
        ecran.draw(renderer,420,270,400,100);
        
        SDL_Rect tab ;
        tab.x = 480;  tab.y= 330; tab.w = 285.4; tab.h = 20;
        SDL_RenderCopy(renderer,font_im19.getTexture(),nullptr,&tab);

        SDL_Rect tab1 ;
        tab1.x = 580;  tab1.y= 270; tab1.w = 70.4; tab1.h = 60;
        SDL_RenderCopy(renderer,font_im20.getTexture(),nullptr,&tab1);

        SDL_Rect tab2 ;
        tab2.x = 520;  tab2.y= 370; tab2.w = 70.4; tab2.h = 20;
        SDL_RenderCopy(renderer,font_im21.getTexture(),nullptr,&tab2);

        SDL_Rect tab3 ;
        tab3.x = 650;  tab3.y= 370; tab3.w = 70.4; tab3.h = 20;
        SDL_RenderCopy(renderer,font_im22.getTexture(),nullptr,&tab3);
    }

    Score();
    Niveau();

}


void SDLSimple::sdlBoucle () {
    SDL_Event events;

    unsigned int y;
    double lastFrameTime = steady_clock::now().time_since_epoch().count();
    bool quit = false;
    bool quitHomeScreen = false;
    bool quitSynopsisScreen = true;
    bool quitJeu = true;

    while (!quit) {
        // Afficher l'écran d'accueil
        if (!quitHomeScreen) {
            home();
            quitSynopsisScreen = true;

        }
        // Afficher l'écran de synopsis
        else if (!quitSynopsisScreen) {
            Synopsis();
            quitJeu = true;
        }
        else if (!quitJeu){
            sdlAff();
        }

        while (SDL_PollEvent(&events)) {
            switch (events.type) {
                case SDL_QUIT:
                    quit = true;
                    break;
                case SDL_KEYDOWN:
                    switch (events.key.keysym.scancode) {
                        case SDL_SCANCODE_RETURN:
                            quitHomeScreen = true;
                            quitSynopsisScreen = false;
                            break;
                        case SDL_SCANCODE_SPACE:
                            quitSynopsisScreen = true;
                            quitJeu = false;
                            break;
                        case SDL_SCANCODE_UP:
                            y = 4;
                            break;
                        case SDL_SCANCODE_DOWN:
                            y = 1;
                            break;
                        case SDL_SCANCODE_LEFT:
                            y = 3;
                            break;
                        case SDL_SCANCODE_RIGHT:
                            y = 2;
                            break;
                        case SDL_SCANCODE_R:
                            jeu.reinitialise();
                            y = 2;
                            break;
                        case SDL_SCANCODE_ESCAPE:
                        case SDL_SCANCODE_Q:
                            quit = true;
                            break;
                        default:
                            break;
                    }
                    Mix_PlayChannel(-1, sound, -1); // Jouer le son
                    break;
                default:
                    break;
            }
        }

        // Mettre à jour le jeu
        if (steady_clock::now().time_since_epoch().count() - lastFrameTime > jeu.gettemps()) {
            jeu.controleJeu(y);
            lastFrameTime = steady_clock::now().time_since_epoch().count();
        }

        // Mettre à jour l'affichage
        SDL_RenderPresent(renderer);
    }
}



int main (int argc, char** argv) {
	SDLSimple sj;
	sj.sdlBoucle();
  //  sj.~SDLSimple();
	return 0;
}