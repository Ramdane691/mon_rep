#ifndef _SDLJEU_H
#define _SDLJEU_H




#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_mixer.h>

#include "../core/Jeu.h"

//! \brief Pour gérer une image avec SDL2
class Image {

private:

    SDL_Surface * m_surface;
    SDL_Texture * m_texture;
    bool m_hasChanged;

public:
    Image () ;
    ~Image();
    void loadFromFile (const char* filename, SDL_Renderer * renderer);
    void loadFromCurrentSurface (SDL_Renderer * renderer);
    void draw (SDL_Renderer * renderer, int x, int y, int w=-1, int h=-1);
    SDL_Texture * getTexture() const;
    void setSurface(SDL_Surface * surf);
    void dessinerRectangle(const unsigned int Xmin, const unsigned int Ymin, const unsigned int Xmax, const unsigned int Ymax);
};



/**
    La classe gerant le jeu avec un affichage SDL
*/
class SDLSimple {

private :

	Jeu jeu;
    Basilic bas;
    Galerie gal;

    SDL_Window * window;
    SDL_Renderer * renderer;

    TTF_Font * font;
    Image font_im; 
    Image font_im1;
    Image font_im2;
    Image font_im3;
    Image font_im4;
    Image font_im5;
    Image font_im6;
    Image font_im7;
    Image font_im8;
    Image font_im9;
    Image font_im10;
    Image font_im11;
    Image font_im12;
    Image font_im13;
    Image font_im14;
    Image font_im15;
    Image font_im16;
    Image font_im17;

    Image font_im18;
    Image font_im19;
    Image font_im20;
    Image font_im21;

    Image font_im22;
    Image font_im23;

    SDL_Color font_color1;
    SDL_Color font_color2;
    SDL_Color font_color3;

    SDL_Color font_color4;
    SDL_Color font_color5;
    SDL_Color font_color6;

    Mix_Chunk * sound;
    bool withSound;

    Image im_basilc;   

    Image im_mur;

    Image im_sorcier1;
    Image im_sorcier2;
    Image im_sorcier3;
    Image im_sorcier4;

    Image im_sorcier5;
    Image im_sorcier6;
    Image im_sorcier7;
    Image im_sorcier8;

    Image im_pillule1;  /// pilule qui fait accelerer x1
    Image im_pillule2;  /// pilule qui ralentire x1
    Image im_pillule3;  /// pilule qui fait accelerer x2
    Image im_pillule4;  /// pilule qui ralentire x2

    Image ecran;

    bool quit = false;
public :

    /**
     * @brief constructeur
    */
    SDLSimple ();

    /**
     * @brief destructeur
    */
    ~SDLSimple ();

    /**
     * @brief chrage les ressources
    */
    bool loadRessources();   

    /**
     * @brief libere les ressource
    */
    void cleanup();

    /**
     * @brief boucle d'affichage complet du jeu
    */
    void sdlBoucle ();

    /**
     * ecran d'afficha du jeu
    */
    void sdlAff ();

    /**
     * @brief affichage de l'ecran dacceuil
    */
    void home();

    /**
     * @brief c'est le deucxieme ecran
    */
    void Synopsis();

    /**
     * @brief fonction pour afficher le score
    */
    void Score();

    /**
     * @brief fonction pour afficher le niveau
    */
    void Niveau();

};

#endif