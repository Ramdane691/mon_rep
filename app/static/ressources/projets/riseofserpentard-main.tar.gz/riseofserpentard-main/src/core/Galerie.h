#ifndef GALERIE_H
#define GALERIE_H


#include <vector>
#include <iostream>
#include "Vec2.h"
#include "cassert"

/**
* @class Galerie
* @brief La classe Galerie représente un espace de jeu, dans lesquelles les personnages se déplaceront
*/
class Galerie
{
    private:
        unsigned int largeur; ///< Largeur de la galerie 
        unsigned int hauteur; ///< Hauteur de la galerie

    public:

        enum TypeCase { COULOIR=' ', MUR='#' }; ///< Types de cases dans la galerie 
        TypeCase m_G[100][100]; ///< Matrice qui représente les cases de la galerie

        /**
        * @brief Constructeur par défaut de la classe Galerie
        */
        Galerie();
        
        /**
        * @brief Renvoie la hauteur de la galerie
        * @return Hauteur de la galerie
        */
        unsigned int getHauteur()const;    
        
        /**
        * @brief Renvoie la largeur de la galerie
        * @return Largeur de la galerie
        */
        unsigned getLargeur()const;    
        
        /**
        * @brief Vérifie qu'une position n'est pas hors-galerie, ni un mur2
        * @param pos La position à vérifier
        * @return true si la position est valide, false sinon
        */        
        bool dansLeMur(const Vec2 pos) const;  

        /**
        * @brief Renvoie le type de case à une certaine position (coordonées)
        * @param x Coordonnée x
        * @param y Coordonnée y
        * @return Type de case
        */
        TypeCase getXY (const int x, const int y) const;
             
        /**
         * @brief Renvoie le contenu de la case à une position (coordonées) sous forme de caractère
         * @param x Coordonnée x
         * @param y Coordonnée y
         * @return Le contenu de la case sous forme de caractère
         */
        unsigned char getXYasChar (const int x, const int y) const;

        /**
        *@brief Effectue des test sur la classe Galerie pour s'assurer que toute les fonctions fonctionnes correctement
        * 
        */    
        static void testRegression();

};

inline unsigned int Galerie::getLargeur() const { return largeur; }

inline unsigned int Galerie::getHauteur() const { return hauteur; }

inline Galerie::TypeCase Galerie::getXY(const int x, const int y) const { return m_G[x][y]; }

inline unsigned char Galerie::getXYasChar(const int x, const int y) const {
    return (char)(m_G[x][y]);
}


#endif 


