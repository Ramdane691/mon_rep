#ifndef PILULEM_H
#define PILULEM_H

#include "Vec2.h"
#include "Galerie.h"

class Galerie;

/**
 * @class PiluleM
 * @brief Classe qui représente une pilule magique
 */
class PiluleM {
    private:
        Vec2 position; ///< Position de la pilule magique 

    public:

        /**
         * @brief Constructeur par défaut de la classe PiluleM
         */
        PiluleM();

        /**
         * @brief Constructeur de la classe PiluleM
         * @param position Position de la pilule magique
         * @param pouvoir Pouvoir de la pilule magique
         */
        PiluleM(const Vec2& position);

        /**
         * @brief Accede à la coordonnée x de la position de la pilule magique dans la galerie
         * @return Coordonnée x de la position de la pilule magique dans la galerie
         */
        unsigned int getX() const;

        /**
         * @brief Accede à la coordonnée y de la position de la pilule magique dans la galerie
         * @return Coordonnée y de la position de la pilule magique dans la galerie
         */
        unsigned int getY() const;

        /**
         * @brief Change la position de la pilule magique dans la galerie
         * @param g Galerie dans laquelle la pilule magique change de position
         * @return Nouvelle position de la pilule magique dans la galerie
         */
        void reinitialisePos(const Galerie &g);

        /**
        * @brief Effectue des test sur la classe PiluleM pour s'assurer que toute les fonctions fonctionnes correctement
        * 
        */
        static void testRegression();
};

#endif 
