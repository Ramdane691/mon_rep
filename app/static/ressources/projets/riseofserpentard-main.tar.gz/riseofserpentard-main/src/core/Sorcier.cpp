#include"Sorcier.h"
#include <iostream>
#include "Galerie.h"  
#include <cassert>


using namespace std;

Sorcier::Sorcier() :position(1, 5), dir(0){ 
}

Sorcier::Sorcier(Vec2 pos, int d){
    position = pos; dir = d;
}


unsigned int Sorcier::getPosX() const {
    return position.x;
}

unsigned int Sorcier::getPosY() const {
    return position.y;
}

void Sorcier::bougeAuto(const Galerie &g) { 

    int dx[4] = {1, 0, -1, 0}; 
    int dy[4] = {0, 1, 0, -1}; 

    unsigned int xtmp = position.x + dx[dir]; 
    unsigned int ytmp = position.y + dy[dir];

    if (!g.dansLeMur(Vec2(xtmp, ytmp))) {
        position.x = xtmp;
        position.y = ytmp;
    } else {
        dir = rand()%4;
    }
}

void Sorcier::reinitialisePos(const Galerie &g){

    Vec2 tmp;
    do{
        tmp.x= rand()%86+1;
        tmp.y= rand()%50+1;
    }while (g.dansLeMur(tmp));

    position = tmp;
    
}

void Sorcier::testRegression() {
    
    Sorcier sorcier1;

    assert(sorcier1.getPosX() == 1);
    assert(sorcier1.getPosY() == 5);
    
    Vec2 position(3, 4);
    Sorcier sorcier2(position, 1);

    assert(sorcier2.getPosX() == 3);
    assert(sorcier2.getPosY() == 4);
    assert(sorcier2.dir == 1);

    Galerie galerie;
    sorcier2.reinitialisePos(galerie);
    assert(galerie.dansLeMur(Vec2( sorcier2.getPosX(), sorcier2.getPosY())) == false);
    sorcier1.bougeAuto(galerie); 

    cout << "les tests de la classe Sorcier sont ok!!" << endl;


}

