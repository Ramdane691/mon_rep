
#ifndef VEC2_H
#define VEC2_H

/**
 * @struct Vec2
 * @brief Représente un vecteur 2D avec des composantes entières, qui permettra d'initialiser tout objet dans l'espace
 */
struct Vec2{
    unsigned int x; ///< La composante x du vecteur 
    unsigned int y; ///< La composante y du vecteur 

    /**
     * @brief Constructeur par défaut de la structure Vec2
     */
    Vec2();

    /**
     * @brief Constructeur par copie de la structure Vec2
     * @param a Valeur de la composante x
     * @param b Valeur de la composante y
     */
    Vec2(unsigned int a, unsigned int b);

    /**
     * @brief Surcharge de l'opérateur d'addition + pour Vec2
     * @param other Le Vec2 à ajouter à ce Vec2
     * @return La somme des deux Vec2
     */
    Vec2 operator+(const Vec2& other) const;

    /**
     * @brief Surcharge de l'opérateur de soustraction - pour Vec2
     * @param other Le Vec2 à soustraire à ce Vec2
     * @return La différence des deux Vec2
     */
    Vec2 operator-(const Vec2& other) const;

    /**
     * @brief Surcharge de l'opérateur d'affectation = pour Vec2
     * @param other Le Vec2 à copier
     * @return Une réfunsigned érence à ce Vec2 après l'affectation
     */
    Vec2& operator=(const Vec2& other);

    /**
     * @brief Surcharge de l'opérateur de comparaison inférieur < pour Vec2
     * @param other Le Vec2 à comparer
     * @return true si ce Vec2 est inférieur à l'autre, sinon false
     */
    bool operator<(const Vec2& other) const;

    /**
     * @brief Surcharge de l'opérateur de comparaison supérieur > pour Vec2
     * @param other Le Vec2 à comparer
     * @return true si ce Vec2 est supérieur à l'autre, sinon false
     */
    bool operator>(const Vec2& other) const; 


    /**
     * @brief Effectue des tests de régression pour la classe Vec2 pour vérifier le bon fonctionnement des fonctions
     */
    static void testRegression();

};

#endif