#include "Jeu.h"


unsigned int dir;


Jeu::Jeu(): bas(), gal() {
	vitesse = .8;
	temps = 6.0e7;
	score = 0;
	niveau = 1;
	mur = false;
	csc = false;
}

unsigned int directionnormal(unsigned int y)
{	

	if (dir==1 && y ==4)
	{
		dir=1;
	}
	else if (dir==2 && y==3)
	{
		dir=2;
	}
	else if (dir==3 && y==2)
	{
		dir=3; 
	}
	
	else if (dir==4 && y==1)
	{
		dir=4;
	}
	else {dir=y;}
	return dir;
}



void Jeu::controleJeu(unsigned int a)
{
	a = directionnormal(a);

	
	if(bas.corp.getvaleur(1).x == sorc1.getPosX() && bas.corp.getvaleur(1).y == sorc1.getPosY()){
		bas.mouvement(a ,gal);
		bas.corp.setIemeElement(bas.corp.getvaleur(0),bas.corp.getT()+1);
		score++;    //pouffe-souffle
		sorc1.reinitialisePos(gal); 
	}else if(bas.corp.getvaleur(1).x == sorc2.getPosX() && bas.corp.getvaleur(1).y == sorc2.getPosY()){
		bas.mouvement(a, gal);
		bas.corp.setIemeElement(bas.corp.getvaleur(0),bas.corp.getT()+1);
		score+=3;   //serre-daigle
		sorc2.reinitialisePos(gal);
	}else if(bas.corp.getvaleur(1).x == sorc3.getPosX() && bas.corp.getvaleur(1).y == sorc3.getPosY()){
		bas.mouvement(a, gal);
		bas.corp.setIemeElement(bas.corp.getvaleur(0),bas.corp.getT()+1);
		score+=5;   //griffon d'or
		sorc3.reinitialisePos(gal);

	}else if(bas.corp.getvaleur(1).x == sorc4.getPosX() && bas.corp.getvaleur(1).y == sorc4.getPosY()){
		csc = true;   //premier serpentard
	}else if(bas.corp.getvaleur(1).x == sorc5.getPosX() && bas.corp.getvaleur(1).y == sorc5.getPosY()){
		csc = true;   //deuxieme serpentard
			
	}else if(bas.corp.getvaleur(1).x == sorc6.getPosX() && bas.corp.getvaleur(1).y == sorc6.getPosY()){
		csc = true;   //troisieme serpentard
			
	}else if(bas.corp.getvaleur(1).x == sorc7.getPosX() && bas.corp.getvaleur(1).y == sorc7.getPosY()){
		csc = true;   //quatrieme serpentard
			
	}else if(bas.corp.getvaleur(1).x == sorc8.getPosX() && bas.corp.getvaleur(1).y == sorc8.getPosY()){
		csc = true;   //cinquieme serpentard
			
	}else if (gal.dansLeMur(bas.corp.getvaleur(bas.corp.getT()-1)) ){
		mur = true;
	
	}else if(bas.corp.getvaleur(1).x == pilule1.getX() && bas.corp.getvaleur(1).y == pilule1.getY()){
		bas.mouvement(a, gal);
		vitesse = 2.;   //accelere x1

		pilule1.reinitialisePos(gal);

	}else if (bas.corp.getvaleur(1).x == pilule2.getX() && bas.corp.getvaleur(1).y == pilule2.getY()){
		bas.mouvement(a, gal);
		vitesse = 0.5;
		temps = 10.0e7;     //ralentisseur x1
		pilule2.reinitialisePos(gal);

	}else if (bas.corp.getvaleur(1).x == pilule3.getX() && bas.corp.getvaleur(1).y == pilule3.getY()){
		bas.mouvement(a, gal);
		vitesse = 0.5;
		temps = 2.0e7;     //accelere x2
		pilule3.reinitialisePos(gal);

	}else if (bas.corp.getvaleur(1).x == pilule4.getX() && bas.corp.getvaleur(1).y == pilule4.getY()){
		bas.mouvement(a, gal);
		vitesse = 0.5;
		temps = 15.0e7;     //ralentisseur x2
		pilule4.reinitialisePos(gal);

	}else{
		bas.mouvement(a, gal);
		sorc1.bougeAuto(gal);
		sorc2.bougeAuto(gal);
		sorc3.bougeAuto(gal);
		sorc4.bougeAuto(gal);
	}

	if (score >= 10 && score <30) {
		niveau = 2;
		sorc5.bougeAuto(gal);
	} else if (score >= 30 && score <50) {
		niveau = 3;
		sorc6.bougeAuto(gal);
	} else if (score >= 50 && score <100){
		niveau = 4;
		sorc7.bougeAuto(gal);
	}else if (score >= 100){
		niveau = 5;
		sorc8.bougeAuto(gal);
	}

}

void Jeu::reinitialise(){
	vitesse = 0.8;
	temps = 6.0e7;
	score = 0;
	niveau = 1;
	bas.reinitialise();
}



double Jeu::gettemps() const {
	if (vitesse == 2) return temps/2;
	
	else return temps - (score * 4.0e5); 
}


void Jeu::testRegression() {
    Jeu jeu_test;

    // Test d'un mouvement normal
    jeu_test.controleJeu(1); //manque les assert

    // Affichage des résultats des tests
    std::cout << "Les tests de la classe Jeu sont OK !!" << std::endl;
}

