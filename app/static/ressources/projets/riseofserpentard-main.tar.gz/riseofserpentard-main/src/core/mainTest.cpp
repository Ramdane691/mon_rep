#include <cassert>

#include <iostream>

//#include "Vec2.h"
#include "Galerie.h"
#include "TableauDynamique.h"
#include "Sorcier.h"
#include "PiluleM.h"
#include "Basilic.h" 
#include "Jeu.h"


/*#include "../txt/WinTxt.h"
#include "../sdl/sdlJeu.h"*/

int main(){

    Vec2::testRegression();
//    TableauDynamique::testRegression();
//    Galerie::testRegression();
    Sorcier::testRegression();
    PiluleM::testRegression();
    Basilic::testRegression();
    Jeu::testRegression();


    std::cout<<"................toutes les classes ont été testés :-)"<<std::endl;

    return 0;


}