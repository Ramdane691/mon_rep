#include "PiluleM.h"
#include<iostream>
#include<string>
#include <cassert>

using namespace std;

PiluleM::PiluleM() : position(Vec2(0, 0)) {}

PiluleM::PiluleM(const Vec2& position) : position(position) {}

unsigned int PiluleM::getX() const { 
    return position.x; 
}

unsigned int PiluleM::getY() const { 
    return position.y;
}

void PiluleM::reinitialisePos(const Galerie &g){

    Vec2 tmp;
    do{
        tmp.x= rand()%86+1;
        tmp.y= rand()%50+1;
    }while (g.dansLeMur(tmp));

    position = tmp;
    
}


void PiluleM::testRegression(){
   
    PiluleM pilule1;

    assert(pilule1.getX() == 0);
    assert(pilule1.getY() == 0);

    PiluleM pilule2( Vec2{3, 4} );

    assert(pilule2.getX() == 3);
    assert(pilule2.getY() == 4);
   
    Galerie galerie; 
    pilule1.reinitialisePos(galerie);
    assert(galerie.dansLeMur(Vec2( pilule1.getX(),pilule1.getY())) == false);

    cout << "Les tests de la classe PiluleM sont ok!!"<< endl;

   
}