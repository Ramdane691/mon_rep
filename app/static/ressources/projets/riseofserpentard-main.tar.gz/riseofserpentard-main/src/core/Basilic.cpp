#include "Basilic.h"
#include <cassert>


Basilic::Basilic()
{
    direction= Vec2(3+1,40);
}


Basilic::~Basilic(){}

void Basilic::reinitialise(){
    corp.reinitialise();   
    direction= Vec2((corp.getvaleur(corp.getT()).x)+1,(corp.getvaleur(corp.getT()).y));    
}

void Basilic::mouvementdir(unsigned int y) 
{
    if (y == 1)
  {
    direction.y = direction.y + 1 ;
  }
  if (y == 2)
  {
    direction.x = direction.x + 1;
  }
  if (y == 3)
  {
      direction.x = direction.x - 1;
  }
  if (y == 4)
  {
      direction.y = direction.y - 1;
  } 
}

void Basilic::mouvement(unsigned int y, const Galerie& d) {
    if (y == 1 || y == 2 || y == 3 || y == 4) {
      corp.deplacement(direction);
          mouvementdir(y);
    }
}


void Basilic::testRegression() {
    // Création d'un Basilic pour les tests
    Basilic b;
    Galerie ga; // Vous devez créer une instance de Galerie pour les tests

    /*b.reinitialise();
    assert( (b.direction.x == b.corp.getvaleur(b.corp.getT()).x)+1 && (b.direction.y == b.corp.getvaleur(b.corp.getT()).y) ); */

    std::cout << "Les tests de la classe Basilic sont OK !!" << std::endl;
}
