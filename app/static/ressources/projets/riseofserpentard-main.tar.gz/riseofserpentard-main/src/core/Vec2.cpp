#include "Vec2.h"
#include <iostream>
#include <cassert>

using namespace std;

Vec2::Vec2() {
    x = 0;
    y = 0;
}

Vec2::Vec2(unsigned int a, unsigned int b) {
    x = a;
    y = b;
}

Vec2 Vec2::operator-(const Vec2& other) const {
    return Vec2(x - other.x, y - other.y);
}

Vec2 Vec2::operator+(const Vec2& other) const {
    return Vec2(x + other.x, y + other.y);
}

Vec2& Vec2::operator=(const Vec2& other) {
    if (this != &other) {
        x = other.x;
        y = other.y;
    }
    return *this;
}

bool Vec2::operator<(const Vec2& other) const {
    if (x < other.x)
        return true;
    else if (x == other.x)
        return y < other.y;
    return false;
}

bool Vec2::operator>(const Vec2& other) const {
    if (x > other.x)
        return true;
    else if (x == other.x)
        return y > other.y;
    return false;
}

void Vec2::testRegression() {
    Vec2 vec1;
    assert(vec1.x == 0 && vec1.y == 0);

    Vec2 vec2(3, 5);
    assert(vec2.x == 3 && vec2.y == 5);

    Vec2 vec3 = vec2 - vec1;
    assert(vec3.x == 3 && vec3.y == 5);

    Vec2 vec4 = vec2 + vec1;
    assert(vec4.x == 3 && vec4.y == 5);

    assert(vec1 < vec2);
    assert(!(vec2 < vec1));
    assert(!(vec1 > vec2));
    assert(vec2 > vec1);

    cout << "Tous les tests de régression pour la structure Vec2 sont ok!" << endl;
}
