#ifndef _JEU_H
#define _JEU_H

#include "Galerie.h"
#include "Basilic.h"
#include "PiluleM.h"
#include "TableauDynamique.h"
#include "Sorcier.h"


/**
 * @class Jeu
 * @brief la classe qui gere tout notre jeu
 * 
*/
class Jeu
{
    private: 
        Basilic bas; /// le basilic

        Sorcier sorc1 {Vec2(5,5) , 0};  /// sorcier pouffe souffle
        Sorcier sorc2{Vec2(1,10),1};  /// sorcier sert d'aigle
        Sorcier sorc3{Vec2(10,5),2};  /// sorcier griffon d'or la maison qui rapporte le plus de point 
        Sorcier sorc4{Vec2(15,5),3};  ///un sorcier serpentard

        Sorcier sorc5{Vec2(1,1),3};  /// un sorcier serpentard
        Sorcier sorc6{Vec2(1,1),3};  /// un sorcier serpentard
        Sorcier sorc7{Vec2(1,1),3};  /// un sorcier serpentard
        Sorcier sorc8{Vec2(1,1),3};  /// un sorcier serpentard

        Galerie gal;  /// la galerie dans laquelle circule le basilic

        PiluleM pilule1{Vec2(7,6)};  ///< Pilule Malus qui augmente la vitesse d'affichage
        PiluleM pilule2{Vec2(19,40)}; ///< Pillule bonus qui diminue la vitesse d'affichage
        PiluleM pilule3{Vec2(16,43)}; ///< Pillule bonus qui diminue la vitesse d'affichage
        PiluleM pilule4{Vec2(12,40)}; ///< Pillule bonus qui diminue la vitesse d'affichage
        PiluleM pilule5{Vec2(19,43)}; ///< Pillule bonus qui diminue la vitesse d'affichage 


        double temps;   ///< temps d'affichage 
        int vitesse;  ///< vitesse d'affichage
        int score;   ///< score
        int niveau;   ///< niveau de jeu

        bool mur;  ///< booleen qu'on va utiliser pour voir si le basilic est dans le mur
        bool csc;  ///< booleen qu'on va utiliser pour voir si le basilic mange un sorcier serpetard

        

    public:

        /**
         * @brief constructeur par defaut de la classe 
        */
        Jeu();
        const Galerie &getConstGalerie() const;

        /**
         * @brief renvoie la donnée membre d'un sorcier
        */
        const Sorcier &getConstSorc1() const;
        
        /**
        * @brief renvoie la donnée membre d'un sorcier
        */
        const Sorcier &getConstSorc2()const;
        /**
        * @brief renvoie la donnée membre d'un sorcier
        */
        const Sorcier &getConstSorc3()const;
        
        /**
        * @brief renvoie la donnée membre d'un sorcier
        */
        const Sorcier &getConstSorc4()const;

        /**
        * @brief renvoie la donnée membre d'un sorcier
        */
        const Sorcier &getConstSorc5()const;

        /**
        * @brief renvoie la donnée membre d'un sorcier
        */
        const Sorcier &getConstSorc6()const;

        /**
        * @brief renvoie la donnée membre d'un sorcier
        */
        const Sorcier &getConstSorc7()const;

        /**
        * @brief renvoie la donnée membre d'un sorcier
        */
        const Sorcier &getConstSorc8()const;

        /**
        * @brief renvoie la donnée membre de la pillule 1
        */
        const PiluleM &getConstPilule1()const;

        /**
        * @brief renvoie la donnée membre de la pillule 2
        */
        const PiluleM &getConstPilule2()const;

        /**
        * @brief renvoie la donnée membre de la pillule 3
        */
        const PiluleM &getConstPilule3()const;

        /**
        * @brief renvoie la donnée membre de la pillule 4
        */
        const PiluleM &getConstPilule4()const;

        /**
         * @brief retourne la donnée membre du basilic
        */
        const Basilic &getConstBasilic() const; 

        /**
        * @brief la fonction qui controle tout le jeu: deplacement, direction, pillule...
        * @param a direction du basilic
        */
        void controleJeu(unsigned int a);  

        /**
         * @brief reinitialise le jeu
        */
        void reinitialise();

        /**
         * @brief test si le basilic est dans le mur
        */
        bool getMur();

        /**
         * @brief test si le basilic a mangé un sorcier qu'il ne devait pas manger (serpentard)
        */
        bool getCsc();

        /**
         * @brief retourne la donnée temps
        */
        double gettemps() const;

        /**
         * @brief retourne la donnee score
        */
        int getscore() const;

        /**
         *@brief retourne la donnee score
        */
        int getniveau() const;

        /**
         * @brief test la classe Jeu
        */
        static void testRegression(); 
};

inline const Galerie &Jeu::getConstGalerie() const { return gal;}
inline const Basilic &Jeu::getConstBasilic() const {return bas;}

inline const Sorcier &Jeu::getConstSorc1() const { return sorc1; }
inline const Sorcier &Jeu::getConstSorc2() const { return sorc2; }
inline const Sorcier &Jeu::getConstSorc3() const { return sorc3; }
inline const Sorcier &Jeu::getConstSorc4() const { return sorc4; }

inline const Sorcier &Jeu::getConstSorc5() const { return sorc5; }
inline const Sorcier &Jeu::getConstSorc6() const { return sorc6; }
inline const Sorcier &Jeu::getConstSorc7() const { return sorc7; }
inline const Sorcier &Jeu::getConstSorc8() const { return sorc8; }

inline const PiluleM &Jeu::getConstPilule1() const { return pilule1; }
inline const PiluleM &Jeu::getConstPilule2() const { return pilule2; }
inline const PiluleM &Jeu::getConstPilule3() const { return pilule3; }
inline const PiluleM &Jeu::getConstPilule4() const { return pilule4; }

inline int Jeu::getscore() const{ return score; }
inline int Jeu::getniveau() const{ return niveau; }

inline bool Jeu::getCsc(){ return ((bas.corp.getvaleur(1).x == sorc4.getPosX() && bas.corp.getvaleur(1).y == sorc4.getPosY()) || (bas.corp.getvaleur(1).x == sorc5.getPosX() && bas.corp.getvaleur(1).y == sorc5.getPosY()) || (bas.corp.getvaleur(1).x == sorc6.getPosX() && bas.corp.getvaleur(1).y == sorc6.getPosY()) || (bas.corp.getvaleur(1).x == sorc7.getPosX() && bas.corp.getvaleur(1).y == sorc7.getPosY()) || (bas.corp.getvaleur(1).x == sorc8.getPosX() && bas.corp.getvaleur(1).y == sorc8.getPosY()) ); }
inline bool Jeu::getMur(){ return  gal.dansLeMur(bas.corp.getvaleur(bas.corp.getT()-1)); }

#endif
