#ifndef BASILC_H
#define BASILC_H


#include "TableauDynamique.h"
#include "Galerie.h"

/**
 * @class Sorcier
 * @brief La classe Basilic représente un serpent, personnage princapale du jeu
 */
class Basilic{
    private:


    public:

        TableauDynamique corp; ///< Corps du basilic 
        Vec2 direction;  ///< Direction du basilic, décrit en coordonées

        /**
         * @brief Constructeur par défaut de la classe Basilic qui initialise mord, galerie, et direction
         */
        Basilic();

        /**
        * @brief Destructeur de la classe Basilic
        */
        ~Basilic();

        /**
        * @brief Effectue le mouvement du Basilic dans une direction donnée 
        * @param y La direction du mouvement (1: vers le haut, 2: vers la droite, 3: vers la gauche, 4: vers le bas)
        */
        void mouvementdir(unsigned int y);

        /**
        * @brief Effectue le mouvement du Basilic en fonction d'une direction et de la galerie
        * @param y La direction du mouvement (1: vers le haut, 2: vers la droite, 3: vers la gauche, 4: vers le bas)
        * @param d La galerie dans laquelle progresse le Basilic
        */
        void mouvement(unsigned int y , const Galerie & d);

        /**
        * @brief Effectue des test sur la classe Basilic pour s'assurer que toute les fonctions fonctionnes correctement
        * 
        */
        static void testRegression();

        /**
         * @brief reinitialise la position
        */
        void reinitialise();

};

#endif