#ifndef _TAB_DYN
#define _TAB_DYN

#include "Vec2.h"

/**
 * @class TableauDynamique
 * @brief Représente un tableau dynamique de vecteurs 2D
 */
class TableauDynamique {
    private: 

        unsigned int capacite; ///< Capacité maximale du tableau 
        unsigned int taille_utilisee; ///< Taille actuelle du tableau 
    public:

        Vec2 *ve; ///< Pointeur vers le tableau de vecteurs 

        /**
        * @brief Constructeur par défaut de la classe TableauDynamique
        */
        TableauDynamique();

        /**
        * @brief Destructeur de la classe TableauDynamique
        */        
        ~TableauDynamique();

        /**
         * @brief Ajoute un élément au tableau dynamique
         * @param a Vec2 à ajouter
         */
        void ajouterElement(Vec2 a);

        /**
         * @brief Récupère la taille du tableau dynamique
         * @return Taille du tableau dynamique
         */
        unsigned int getTaille() const;

        /**
         * @brief Récupère la valeur à l'indice en parametre, dans le tableau dynamique
         * @param indice L'indice de l'élément à récupérer
         * @return La valeur à l'indice en parametre
         */
        Vec2 getvaleur(unsigned int indice) const;
        
        
        /**
         * @brief Modifie l'élément à l'indice passer en parametre dans le tableau dynamique
         * @param a Le nouveau Vec2 à mettre à l'indice passer en parametre
         * @param indice L'indice de l'élément à modifier
         */
        void setIemeElement(Vec2 a, unsigned int indice);

        /**
         * @brief Récupère la taille utilisée actuellement du tableau dynamique
         * @return La taille utilisée du tableau dynamique
         */
        unsigned int getT() const;

        /**
         * @brief Récupère la capacité maximale du tableau dynamique
         * @return La capacité maximale du tableau dynamique
         */
        unsigned int getca() const;

        /**
         * @brief Déplace le tableau dynamique selon le vecteur passer en parametre
         * @param D Le vecteur de déplacement
         */
        void deplacement(Vec2 D);

        /**
         * @brief Supprime l'élément à l'indice passer en parametre dans le tableau dynamique
         * @param indice L'indice de l'élément à supprimer
         */
        void supprimerElement(unsigned int indice);

        /**
         * @brief Vérifie si le vecteur passer en parametre, est présent dans le tableau dynamique
         * @param D Le vecteur à rechercher
         * @return true si le vecteur est présent, sinon false
         */
        bool estdanstab(Vec2 D);

        /**
         * @brief fonction quon va utiliser pour reinitialiser la position et la taille du basilic
        */
        void reinitialise();

        /**
         * @brief Effectue des tests de régression pour la classe TableauDynamique pour vérifier le bon fonctionnement des fonctions
         */
        static void testRegression();
};

#endif

