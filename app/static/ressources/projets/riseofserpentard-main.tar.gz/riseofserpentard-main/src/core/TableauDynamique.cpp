
#include "TableauDynamique.h"


#include <iostream>
#include <stdlib.h>
#include <cassert>
using namespace std;


TableauDynamique::TableauDynamique () {
    ve = new Vec2 [10];
    capacite = 10;
    taille_utilisee = 3;

    for (unsigned int i=0;i<=taille_utilisee;i++)
    {
      ve[i] = Vec2(3+i,40);  //ce sont les dimmension du plateau
    }
}


TableauDynamique::~TableauDynamique () {
  delete [] ve;
  ve = NULL;
  capacite = 0;
  taille_utilisee = 0;
}


unsigned int TableauDynamique::getTaille() const {
    return taille_utilisee;
}


void TableauDynamique::ajouterElement(Vec2 a) {
    if (taille_utilisee == capacite) {
        // Réallocation du tableau
        capacite *= 2;
        Vec2 *temp = new Vec2[capacite];
        for (unsigned int i = 0; i < taille_utilisee; ++i) {
            temp[i] = ve[i];
        }
        delete[] ve;
        ve = temp;
    }
    ve[taille_utilisee] = a;
    taille_utilisee++;
}



Vec2 TableauDynamique::getvaleur(unsigned int indice) const {
  return ve[indice];
}

void TableauDynamique::setIemeElement ( Vec2 a,unsigned int indice)
 { 
  ve[indice].x = a.x;
  ve[indice].y = a.y;
  taille_utilisee = taille_utilisee +1;
}


unsigned int TableauDynamique::getT() const { return taille_utilisee;}
unsigned int TableauDynamique::getca() const { return capacite;}


void TableauDynamique::deplacement(Vec2 D) {
    // Déplacement des éléments vers la gauche
    
    for (unsigned int i = 0; i < taille_utilisee - 1; ++i) {
        ve[i] = ve[i + 1];
    }
    // Ajout du nouvel élément à la fin
    ve[taille_utilisee - 1] = D;
}



/*bool TableauDynamique::estdanstab(Vec2 D)
 {
   for(unsigned int i=0; i<= taille_utilisee ; i++)
   {
     if (ve[i].x == D.x && ve[i].y == D.y) 
        {
       return true;
        } 
   }
   return false;
 }*/

bool TableauDynamique::estdanstab(Vec2 D) {
    for (unsigned int i = 0; i < taille_utilisee; i++) { // Modifier la condition de la boucle
        if (ve[i].x == D.x && ve[i].y == D.y) {
            return true;
        }
    }
    return false;
}



void TableauDynamique::supprimerElement(unsigned int indice) {
    if (indice >= taille_utilisee)
        throw std::out_of_range("Indice hors limite");

    // Suppression de l'élément à l'indice donné
    for (unsigned int i = indice; i < taille_utilisee - 1; ++i) {
        ve[i] = ve[i + 1];
    }
    taille_utilisee--;

    // Réduction de la capacité si nécessaire
    if (taille_utilisee < capacite / 3) {
        capacite /= 2;
        Vec2 *temp = new Vec2[capacite];
        for (unsigned int i = 0; i < taille_utilisee; ++i) {
            temp[i] = ve[i];
        }
        delete[] ve;
        ve = temp;
    }
}

/*void TableauDynamique::reinitialise(){
    ve = new Vec2 [10];
    capacite = 10;
    taille_utilisee = 3;

    for (unsigned int i=0;i<=taille_utilisee;i++)
    {
      ve[i] = Vec2(3+i,40);  //ce sont les dimmension du plateau
    }
}*/

void TableauDynamique::reinitialise() {
    delete[] ve; // Libérer la mémoire précédemment allouée
    ve = new Vec2[10];
    capacite = 10;
    taille_utilisee = 3;

    for (unsigned int i = 0; i <= taille_utilisee; i++) {
        ve[i] = Vec2(3 + i, 40);  //ce sont les dimensions du plateau
    }
}


void TableauDynamique::testRegression() {
    // Création d'un tableau dynamique
    TableauDynamique tableau;

    // Test de la taille initiale du tableau
    assert(tableau.getTaille() == 3);

    // Ajout d'un élément et vérification de la taille
    tableau.ajouterElement(Vec2(5, 5));
    assert(tableau.getTaille() == 4);

    // Vérification de la valeur x du premier élément
    assert(tableau.getvaleur(0).x == 3);

    // Suppression d'un élément et vérification de la taille mise à jour
    tableau.supprimerElement(0);
    assert(tableau.getTaille() == 3);

    // Vérification que les éléments sont décalés correctement après la suppression
    assert(tableau.getvaleur(0).x == 4);

    // Test du déplacement et vérification de la valeur du dernier élément
    tableau.deplacement(Vec2(10, 10));
    assert(tableau.getvaleur(2).x == 3 && tableau.getvaleur(2).y == 10);

    // Vérification de la présence d'un vecteur dans le tableau
    assert(tableau.estdanstab(Vec2(2, 10)) == false);
    assert(tableau.estdanstab(Vec2(3, 10)) == true);

    // Affichage d'un message indiquant que tous les tests ont réussi
    cout << "Tous les tests de la classe TableauDynamique ont réussi" << endl;
}

