#ifndef _SORCIER_H
#define _SORCIER_H

#include "Vec2.h"
#include "Galerie.h"
#include "Basilic.h"

/**
 * @class Sorcier
 * @brief La classe Sorcier représente un sorcier dans un espace 2D
 */
class Sorcier {

  private:
      Vec2 position; ///< La position du sorcier dans un espace 2D
      unsigned int dir;///< la direction du sorcier

  public:

      /**
       * @brief Constructeur par défaut de la classe Sorcier qui initialise le sorcier à la position (0,0), la direction (1,0) et l'identifiant de la maison à 0
       */
      Sorcier();

      /**
       * @brief constructeur par copie
      */

      Sorcier(Vec2 pos, int d); 

      /**
       * @brief Récupère la composante x de la position du sorcier
       * @return la composante x du sorcier
       */
      unsigned int getPosX() const;

      /**
       * @brief Récupère la composante y de la position du sorcier
       * @return la composante y du sorcier
       */
      unsigned int getPosY() const;

      /**
      * @brief Déplace automatiquement le sorcier dans la galerie
      * @param g La galerie dans laquelle le sorcier se déplace 
      */
      void bougeAuto(const Galerie &g);

      /**
      * @brief Rénitialise la position aux coordonées (1,5)
      * 
      */
      void reinitialisePos(const Galerie &g);

      /**
      * @brief Effectue des test sur la classe Sorcier pour s'assurer que toute les fonctions fonctionnes correctement
      * 
      */
      static void testRegression();

};

#endif
