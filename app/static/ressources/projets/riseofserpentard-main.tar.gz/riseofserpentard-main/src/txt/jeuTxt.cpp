#include <iostream>
#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif // WIN32
#include "WinTxt.h"

#include "jeuTxt.h"
using namespace std;//::chrono;





void txtAff(WinTXT & win, const Jeu & jeu) {

	const Galerie& gal = jeu.getConstGalerie();
	const Basilic& bas = jeu.getConstBasilic();
	const Sorcier& sorc1 = jeu.getConstSorc1();
	const Sorcier& sorc2 = jeu.getConstSorc2();
	const Sorcier& sorc3 = jeu.getConstSorc3();
	const Sorcier& sorc4 = jeu.getConstSorc4();


	win.clear();

    // Affichage de la galerie 
	for(unsigned int x=0;x<gal.getLargeur();++x)
		for(unsigned int y=0;y<gal.getHauteur();++y)
			win.print( x, y, gal.getXYasChar(x,y));

    // Affichage du basilic
	for (unsigned int i = 0;i<=bas.corp.getT();i++)
	{
		//Vec2 temp = bas.corp->getvaleur(i);
		Vec2 temp = bas.corp.getvaleur(i);

		//affichechar(temp,1);
		win.print(temp.x, temp.y, '&');
		
	}

	// Affichage des sorciers 
	win.print(sorc1.getPosX(),sorc1.getPosY(),'S');
	win.print(sorc2.getPosX(),sorc2.getPosY(),'S');
	win.print(sorc3.getPosX(),sorc3.getPosY(),'S');
	win.print(sorc4.getPosX(),sorc4.getPosY(),'S');

	win.draw();
}

void txtBoucle (Jeu & jeu) {
	// Creation d'une nouvelle fenetre en mode texte
	// => fenetre de dimension et position (WIDTH,HEIGHT,STARTX,STARTY)
    WinTXT win (jeu.getConstGalerie().getLargeur(),jeu.getConstGalerie().getHauteur());

	bool ok = true;
	int c;
	//double findeplace = steady_clock::now().time_since_epoch().count();
	unsigned int y;

	do {
	    txtAff(win,jeu);

        #ifdef _WIN32
        Sleep(100);
		#else
		usleep(100000);
        #endif // WIN32

		jeu.controleJeu(y);

		c = win.getCh();
		switch (c) {
			case 'o':    
				y = 4;  //vers le haut
				break;
			case 'l':
				y = 1; //bas
				break;
			case 'm':
				y = 2; //vers la droite
				break;
			case 'k':
				y = 3; //vers la gauche 
				break;
			case 'q':
				ok = false;
				break;
		}

	} while (ok);

}

int main ( int argc, char** argv ) {
    termClear();
	Jeu jeu;
	txtBoucle(jeu);
    termClear();
	return 0;
}
