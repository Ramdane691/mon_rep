#ifndef JEUTXT_H
#define JEUTXT_H


#include "../core/Jeu.h"


void txtBoucle (Jeu & j);



#endif