#ifndef IMAGE_H
#define IMAGE_H

#include "Pixel.h" // Inclure le fichier de définition de Pixel




/**
 * @class Image
 *
 * @brief  La classe Image illustre une image  2D de dimensions défnis préalablement, à l'aide d'ensemble de pixels
 *
 */

class Image{
    private:
        Pixel * tab; /// tableau de pixel

        unsigned int dimx, dimy; ///les dimensions de l'image

    public:

       /**
       * @brief Constructeur par défaut.
       *
       * @brief Initialise une image avec des dimensions par défaut (0, 0),définit le pointeur sur nullptr
       */
       Image();

       /**
       * @brief Constructeur avec dimensions choisis
       *
       * @brief Initialise une image avec les dimensions choisis et alloue le tableau de pixels correspondant
       *
       * @param dimensionX Dimension en largeur 
       * @param dimensionY Dimension en hauteur 
       */
       Image(unsigned int dimensionX, unsigned int dimensionY);

       /**
       * @brief Destructeur.
       *
       * Libère la mémoire allouée sur le tas pour le tableau de pixels, définit le pointeur sur nullptr, et redimentionne l'image à (0,0)
       */     
        ~Image();

       /**
        * @brief Accesseurs qui permet de récupèrer le pixel original de coordonnées (x, y), en vérifiant avant sa validité
        *
        * Cette fonction permet de récupérer le pixel aux coordonnées choisis (x,y).
        * Elle vérifie que les coordonnées sont valides avant de retourner un pointeur vers le pixel.
        *
        * @param x Coordonnée largeur
        * @param y Coordonnée hauteur
        * @return Pointeurs vers le pixel de l'image correspondant aux coordonnées (x, y) ou alors, si les coordonnées ne sont pas valides, un message d'erreur est affiché: "Coordonnées invalides"
        */
       Pixel& getPix(unsigned int x, unsigned int y);
        
       /**
       * @brief Accesseurs qui permet de récupèrer une copie du pixel original de coordonnées (x, y), en vérifiant avant sa validité: version sans modification
       *
       * Cette fonction constante permet de récupérer le pixel aux coordonnées choisis (x,y) sans le modifier
       * Elle vérifie que les coordonnées sont valides avant de retourner une réference constante du pixel original
       *
       * @param x Coordonnée largeur
       * @param y Coordonnée hauteur
       * @return Réference constante du pixel original de l'image correspondant aux coordonnées (x, y) ou alors, si les coordonnées ne sont pas valides, un message d'erreur est affiché: "Coordonnées invalides"
       */

        Pixel getPix(unsigned int x, unsigned int y)const;
        
        
        /**
        * @brief Modifie le pixel de coordonnées (x,y) dans l'image 
        *
        * Cette fonction modifie le pixel à la position (x,y) contenue imperativement dans l'image, avec la couleur donnée
        *
        * @param x Coordonnée en largeur du pixel à modifier
        * @param y Coordonnée en hauteur du pixel à modifier
        * @param couleur Nouvelle couleur à attribuer au pixel 
        * @return Une copie du pixel original de l'image correspondant aux coordonnees (x,y) ou alors, si les coordonnées ne sont pas valides, un message d'erreur est affiché: "Coordonnées invalides"
        * 
        */
       void setPix(unsigned int x, unsigned int y, const Pixel& couleur);
        
        /**
        * @brief Colorie d'une couleur les pixels de l'image qui sont compris dans le rectangle défini par le coin en haut à gauche (Xmin,Ymin) inclus, jusqu'au point en bas à
       droite (Xmax,Ymax) inclus
       *
       * Cette fonction remplit un rectangle délimité par les coordonnées spécifiées, avec la couleur donnée
       *
       * Si les coordonnées du rectangle ne sont pas valides, un message d'erreur est affiché: "Coordonnées invalides"
       *
       * @param Xmin Coordonnée X du coin supérieur gauche du rectangle
       * @param Ymin Coordonnée Y du coin supérieur gauche du rectangle
       * @param Xmax Coordonnée X du coin inférieur droit du rectangle
       * @param Ymax Coordonnée Y du coin inférieur droit du rectangle
       * @param couleur Couleur à appliquer au rectangle 
       *
       */
       void dessinerRectangle(const unsigned int Xmin, const unsigned int Ymin, const unsigned int Xmax, const unsigned int Ymax, const Pixel& couleur);


        /**
        * @brief Efface l'image en la remplissant de la couleur choisis
        *Cette fonction remplit toute l'image avec la couleur choisis, effaçant l'ancienne couleur.
        * La fonction utilise la méthode `dessinerRectangle` pour remplir toute l'image avec la couleur spécifiée
        *
        * @param couleur Couleur de type Pixel, avec laquelle remplir l'image 

       */
        void effacer(const Pixel & couleur);
        
	    /**
        * @brief Effectue une série de tests vérifiant le bon fonctionnement de toutes les fonctions de la classe Image.
        *
        * Cette fonction statique de la classe Image exécute une série de tests pour vérifier le bon fonctionnement des différentes
        * fonctions de la classe. Les tests incluent le constructeur par défaut, le constructeur avec dimensions, les fonctions
        * get et set de pixels, dessinerRectangle et effacer.
        *
        * Les résultats des tests sont validés à l'aide d'instructions assert. Si un test échoue, un message d'erreur est affiché
        * indiquant la nature de l'échec. En cas de succès, un message indiquant que tous les tests de régression ont réussi est affiché
        */
        static void testRegression();


        /**
        * @brief Sauvegarde l'image dans un fichier
        *
        * @param filename Le nom du fichier dans lequel l'image sera sauvegardée
        */
        void sauver(const string & filename) const;
        
        /**
        * @brief Ouvre une image à partir d'un fichier
        *
        * @param filename Le nom du fichier à partir duquel l'image sera ouverte
        */
        void ouvrir(const string & filename);


        /**
        * @brief affiche les valeurs des pixels sur la console
        */
        void afficherConsole();
        
};


#endif
