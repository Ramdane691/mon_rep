#ifndef IMAGEVIEWER_H
#define IMAGEVIEWER_H

#include <SDL2/SDL_image.h>

#include "Image.h"


 /**
 * @class ImageView
 * @brief La classe ImageView permet d'afficher des images avec SDL
 */

class ImageViewer{
    private :

        SDL_Window * window;  ///Pointeur vers la fenêtre SDL 
        SDL_Renderer * renderer;  ///Pointeur vers le renderer SDL 
        

        //données membres ajoutée pour afficher limage avec 
        SDL_Surface* surface; /// Surface SDL pour manipuler l'image 
        SDL_Texture* texture; /// Texture SDL pour afficher l'image 
        bool has_changed; /// Indicateur booléen pour savoir si l'image a été modifiée 


    public : 

        /**
        * @brief Constructeur par défaut de la classe ImageView et Initialise les membres de la classe et crée la fenêtre SDL
        */
        
        ImageViewer();

	    /**
    	* @brief Destructeur de la classe ImageView , Ferme SDL et libère les ressources associées 
     	*/

        ~ImageViewer();
        
        /**
        * @brief fonction intermediaire qui charge une image à partir d'un fichier et initialise la texture SDL (nous avons choisis la premiere methode pour afficher l'image)
        *
        * @param filename Le nom du fichier image à charger
        * @param renderer Le renderer SDL à utiliser pour la création de la texture
        */
        void loadFromFile(const char* filename, SDL_Renderer * renderer);

       
         /**
        * @brief Dessine une image en SDL avec des coordonnées (x, y) et une taille (w:largeur, h:hauteur)
            *
        * @param renderer Le renderer SDL à utiliser pour le dessin
        * @param x Coordonnée x du coin supérieur gauche de l'image
        * @param y Coordonnée y du coin supérieur gauche de l'image
        * @param w La largeur de l'image
        * @param h La hauteur de l'image
        */
        void draw (SDL_Renderer * renderer, int x, int y, int w, int h);
        
        /**
         * @brief Affiche une image dans la fenêtre SDL et gère les événements associés
         *
         * Cette fonction initialise SDL, crée une fenêtre, charge une image, puis gère les événements SDL
         * jusqu'à ce que l'utilisateur quitte la fenêtre
         *
         * @param im L'image à afficher
         */
        void afficher(const Image& im);


};







#endif