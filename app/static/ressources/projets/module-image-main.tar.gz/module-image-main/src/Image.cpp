#include "Image.h"
#include <cassert>
#include <fstream>



const Pixel Noir(0,0,0);

Image::Image(): dimx(0), dimy(0) { tab = nullptr; }

Image::Image(unsigned int dimensionX, unsigned int dimensionY){
    
    assert(dimensionX > 0 && dimensionY > 0);
    dimx = dimensionX;
    dimy = dimensionY;
    
    tab = new Pixel[dimx*dimy];
    
    for (unsigned int x = 0; x<dimx; x++){
        for (unsigned int y = 0; y<dimy; y++)
            setPix(x,y, Noir);
    }
}

Image::~Image(){
    
    dimx = 0;
    dimy = 0;
    if (tab!=nullptr)
        delete [] tab;
    tab = nullptr;
}


Pixel Image::getPix(unsigned int x, unsigned int y)const {
    if (x < dimx && y < dimy) {
        return tab[y * dimx + x];
    } 

    return tab[0]; // Ou tout autre valeur par défaut qu'on voudrait retourner
}

Pixel& Image::getPix(unsigned int x, unsigned int y) {
    if (x < dimx && y < dimy) {
        return tab[y * dimx + x];
    } 
 
    return tab[0]; // Ou tout autre valeur par défaut qu'on souhaite retourner
}



void Image::setPix(unsigned int x, unsigned int y, const Pixel& couleur){
    tab[y * dimx + x] = couleur;
}

void Image::dessinerRectangle(const unsigned int Xmin, const unsigned int Ymin, const unsigned int Xmax, const unsigned int Ymax, const Pixel& couleur) {
    
    assert(Xmax >= 0 && Xmax < dimx && Ymax >= 0 && Ymax < dimy );

    for (unsigned int x = Xmin; x <= Xmax; x++) {
        for (unsigned int y = Ymin; y <= Ymax; y++) {
            setPix(x, y, couleur);
        }
    }
}

void Image::effacer(const Pixel & couleur){
    dessinerRectangle(0, 0, dimx - 1, dimy - 1, couleur);
}

void Image::sauver(const string & filename) const {
    ofstream fichier (filename.c_str());
    assert(fichier.is_open());
    fichier << "P3" << endl;
    fichier << dimx << " " << dimy << endl;
    fichier << "255" << endl;
    for(unsigned int y=0; y<dimy; ++y)
        for(unsigned int x=0; x<dimx; ++x) {
            Pixel pix = getPix(x,y);
            fichier << +pix.r << " " << +pix.g << " " << +pix.b << " ";
        }
    cout << "Sauvegarde de l'image " << filename << " ... OK\n";
    fichier.close();
}

void Image::ouvrir(const string & filename) {
    ifstream fichier (filename.c_str());
    assert(fichier.is_open());

    //char r,g,b;
    string mot;

    //dimx = dimy = 0;
    fichier >> mot >> dimx >> dimy;
    assert(mot == "P3");     //pour verifie que cest le bon format
    assert(dimx > 0 && dimy > 0);

    if (tab != NULL) delete [] tab;

    tab = new Pixel [dimx*dimy];

    for(unsigned int y=0; y<dimy; ++y)
        for(unsigned int x=0; x<dimx; ++x) {
            unsigned int r,g,b;
            fichier >> r >> g >> b;
            setPix(x,y,Pixel(r,g,b));
        }
    fichier.close();
    cout << "Lecture de l'image " << filename << " ... OK\n";
   // delete [] tab;
}
void Image::afficherConsole()
{
    cout << dimx << " " << dimy << endl;
    for (unsigned int y = 0; y < dimy; ++y)
    {
        for (unsigned int x = 0; x < dimx; ++x)
        {
            Pixel &pix = getPix(x, y);
            cout << +pix.r << " " << +pix.g << " " << +pix.b << " ";
        }
        cout << endl;
    }
}



void Image::testRegression(){
    //constructeur par defaut
    Pixel p1;
    assert(p1.r==0);
    assert(p1.g==0);    
    assert(p1.b==0);

    //constructeur par copie 
    Pixel p2(10,20,30);
    assert(p2.r == 10);
    assert(p2.g == 20);
    assert(p2.b == 30);

    //constructeur de l'img par defaut
    Image Im1;
    assert(Im1.dimx == 0);
    assert(Im1.dimy == 0);
    assert(Im1.tab == nullptr);

    //constructeur de l'img par copie
    Image Im2(10,10);
    assert(Im2.dimx == 10);
    assert(Im2.dimy == 10);
    assert(Im2.tab->b == 0);
    assert(Im2.tab->g == 0);
    assert(Im2.tab->r == 0);

    //accesseur
    assert(Im2.getPix(1,1).b == 0);
    assert(Im2.getPix(1,1).g == 0);
    assert(Im2.getPix(1,1).r == 0);

    //mutateur
    Im2.setPix(1,1,p2);
    assert(Im2.getPix(1,1).b == p2.b);
    assert(Im2.getPix(1,1).g == p2.g);
    assert(Im2.getPix(1,1).r == p2.r);

    //fonction desiner rectengle 
    Im2.dessinerRectangle(1, 1, 4, 4, p2);
    assert(Im2.getPix(2, 2).r == 10 && Im2.getPix(3, 3).g == 20 && Im2.getPix(4, 4).b == 30);

    Pixel Blanc(255,255,255);

    //effacer 
    Im2.effacer(Blanc);
    assert(Im2.getPix(2, 2).r == 255 && Im2.getPix(3, 3).g == 255 && Im2.getPix(4, 4).b == 255);

    //sauver 
    Im2.sauver("./data/Im2.ppm");

    //ouvrir
   Image Im3;
    Im3.ouvrir("./data/Im2.ppm");
    assert(Im3.dimy == Im2.dimy);
    assert(Im3.dimx == Im2.dimx);
    for(unsigned int j = 0; j < Im3.dimy; ++j)
    {
        for(unsigned int i = 0; i < Im3.dimx; ++i)
        {
            assert(Im3.getPix(i, j).r == Im2.getPix(i, j).r);
            assert(Im3.getPix(i, j).g == Im2.getPix(i, j).g);
            assert(Im3.getPix(i, j).b == Im2.getPix(i, j).b);
            
        }
    }


    remove("./data/Im2.ppm");



    cout<<".....................test terminer ok"<<endl;
}





