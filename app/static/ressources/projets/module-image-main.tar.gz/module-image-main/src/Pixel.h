#ifndef PIXEL_H
#define PIXEL_H


#include <iostream>
using namespace std;

/**
 * @struct  Pixel
 * @brief Structure Pixel,  illustrant un pixel d'image, avec 3 composantes rouge (r),verte (g), et bleue(b)
 *
 */

struct Pixel{


   
     
     
    unsigned char r, g, b; ///composante rouge (r) ,verte (g),bleue (b) comprises entre 0 et 255 inclus
    
    /**
     * @brief Constructeur par défaut
     * Initialise le pixel à la couleur noire (0, 0, 0)
     */
  
    Pixel ();
    
    /**
     * @brief Constructeur.
     *
     * @brief Initialise les composantes du pixel (r, g, b) avec les paramètres choisis (nr,ng,nb)
     *
     * @param nr Composante rouge [0;255]
     * @param ng Composante verte [0;255]
     * @param nb Composante bleue [0;255]
     */


    Pixel(unsigned char nr, unsigned char ng, unsigned char nb);
};


#endif
