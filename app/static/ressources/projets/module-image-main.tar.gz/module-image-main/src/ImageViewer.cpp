#include "ImageViewer.h"
#include <cassert>




ImageViewer::ImageViewer() : window(nullptr), renderer(nullptr) {

    // Initialise SDL
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        std::cerr << "Erreur lors de l'initialisation de SDL : " << SDL_GetError() << std::endl;
    }

    // Crée fenêtre
    window = SDL_CreateWindow("ImageViewer", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 800, 600, SDL_WINDOW_SHOWN);
    if (window == nullptr) {
        std::cerr << "Erreur lors de la création de la fenêtre : " << SDL_GetError() << std::endl;
    }

    // Cré e le rendu
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    if (renderer == nullptr) {
        std::cerr << "Erreur lors de la création du rendu : " << SDL_GetError() << std::endl;
    }
}
 

ImageViewer::~ImageViewer() {
    assert(window != nullptr && renderer != nullptr);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    IMG_Quit();
    SDL_Quit();
}




void ImageViewer::loadFromFile (const char* filename, SDL_Renderer * renderer) {
    surface = IMG_Load(filename);
    if (surface == nullptr) {
        string nfn = string("../") + filename;
        cout << "Error: cannot load "<< filename <<". Trying "<<nfn<<endl;
        surface = IMG_Load(nfn.c_str());
        if (surface == nullptr) {
            nfn = string("../") + nfn;
            surface = IMG_Load(nfn.c_str());
        }
    }
    if (surface == NULL) {
        cout<<"Error: cannot load "<< filename <<endl;
        exit(1);
    }

    SDL_Surface * surfaceCorrectPixelFormat = SDL_ConvertSurfaceFormat(surface,SDL_PIXELFORMAT_ARGB8888,0);
    SDL_FreeSurface(surface);
    surface = surfaceCorrectPixelFormat;

    texture = SDL_CreateTextureFromSurface(renderer,surfaceCorrectPixelFormat);
    if (texture == nullptr) {
        cout << "Error: problem to create the texture of "<< filename<< endl;
        exit(1);
    }
}


void ImageViewer::draw (SDL_Renderer * renderer, int x, int y, int w, int h) {
    int ok;
    SDL_Rect r;
    r.x = x;
    r.y = y;
    r.w = (w<0)?surface->w:w;
    r.h = (h<0)?surface->h:h;

    if (has_changed) {
        ok = SDL_UpdateTexture(texture,NULL,surface->pixels,surface->pitch);
        assert(ok == 0);
        has_changed = false;
    }

    ok = SDL_RenderCopy(renderer,texture,NULL,&r);
    assert(ok == 0);
}

void ImageViewer::afficher(const Image& im){

    if(SDL_Init(SDL_INIT_VIDEO) < 0)
    {
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "[debug] %s", SDL_GetError());

    }

    if (SDL_CreateWindowAndRenderer(800, 600, SDL_WINDOW_SHOWN,  &window, &renderer) < 0)
    {
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "[DEBUG] > %s", SDL_GetError());
        SDL_Quit();
    }
    SDL_SetWindowTitle(window, "SDL2");  //jai changé pWindow par window
    im.sauver("./data/affichage.ppm");

    loadFromFile("./data/affichage.ppm",renderer);  //j'ai changé pRenderer par renderer 
    remove("./data/affichage.ppm");
    SDL_Event events;
    bool quit = false;
    
    int windowWidth, windowHeight;
    SDL_GetWindowSize(window, &windowWidth, &windowHeight);
    
    


    int imageWidth = windowWidth;  
    int imageHeight = windowHeight;  

    int x = 0;  
    int y = 0;  
    int l = imageWidth;  // Largeur 
    int h = imageHeight;  // Hauteur 

    while (!quit)
    {
        while (SDL_PollEvent(&events))
        {

            if (events.type == SDL_QUIT) quit = true;
            switch (events.key.keysym.scancode)
            {
            case SDL_SCANCODE_T:  //fonction pour zoomer ++
                x = (l - l*1.25)/2;
                y = (h - h*1.25)/2;
                l = l*1.25;
                h = h*1.25;
                break;
            case SDL_SCANCODE_G: //cest pourd ezoomer --
                x = (l - l / 1.25)/2;
                y = (h - h / 1.25)/2;
                l = l/1.25;
                h = h/1.25;
                break;
            case SDL_SCANCODE_ESCAPE:
                quit = true;
                break;            
            default:
                break;
            }
        }
        
        SDL_RenderClear(renderer);     
        SDL_SetRenderDrawColor(renderer, 211, 211, 211, 255);   
        draw(renderer, x, y, l, h);    
        SDL_RenderPresent(renderer);   
    }
    SDL_DestroyRenderer(renderer);  
    SDL_DestroyWindow(window);   

    SDL_Quit();
}

