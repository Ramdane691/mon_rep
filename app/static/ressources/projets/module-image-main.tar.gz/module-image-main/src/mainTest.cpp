#include "Pixel.h"
#include "Image.h"
#include <cassert>


int main(){
    
    Image::testRegression();

    Image monImage(10, 10);
    Pixel couleur(1, 10, 100); 

    monImage.dessinerRectangle(2, 2, 7, 7, couleur);


    return 0;
}