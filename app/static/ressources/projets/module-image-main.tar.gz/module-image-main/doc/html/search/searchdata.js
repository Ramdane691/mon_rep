var indexSectionsWithContent =
{
  0: "adegilopst~",
  1: "ip",
  2: "adegilopst~"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions"
};

