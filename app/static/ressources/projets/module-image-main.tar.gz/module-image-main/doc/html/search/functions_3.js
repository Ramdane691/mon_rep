var searchData=
[
  ['getpix_24',['getPix',['../classImage.html#adbeb02a3fd22ab2ed38ce6bf7f0955a2',1,'Image::getPix(unsigned int x, unsigned int y)'],['../classImage.html#aa2c1f02bdf9178459b5bb7409ab86648',1,'Image::getPix(unsigned int x, unsigned int y) const']]]
];
