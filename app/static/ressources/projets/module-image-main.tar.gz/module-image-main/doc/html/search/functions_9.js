var searchData=
[
  ['testregression_32',['testRegression',['../classImage.html#a82ffef6c89927b0cc755a3fe2fec637b',1,'Image']]]
];
