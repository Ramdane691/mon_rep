var searchData=
[
  ['sauver_30',['sauver',['../classImage.html#af870cb0c00a370927e6957f99a409586',1,'Image']]],
  ['setpix_31',['setPix',['../classImage.html#a713c922e13a0a05ac88bef756b4ca90d',1,'Image']]]
];
