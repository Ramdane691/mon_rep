var searchData=
[
  ['image_25',['Image',['../classImage.html#a58edd1c45b4faeb5f789b0d036d02313',1,'Image::Image()'],['../classImage.html#a781829417e05ac62d5c1ea090a8844d1',1,'Image::Image(unsigned int dimensionX, unsigned int dimensionY)']]],
  ['imageviewer_26',['ImageViewer',['../classImageViewer.html#a968687d70a4f15be8442212da98ad36b',1,'ImageViewer']]]
];
