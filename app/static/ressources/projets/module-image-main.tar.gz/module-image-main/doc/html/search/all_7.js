var searchData=
[
  ['pixel_10',['Pixel',['../structPixel.html',1,'Pixel'],['../structPixel.html#a27ad99a2f705e635c42d242d530d4756',1,'Pixel::Pixel()'],['../structPixel.html#ae14440155731c2f7e2073b7bbbd596f3',1,'Pixel::Pixel(unsigned char nr, unsigned char ng, unsigned char nb)']]]
];
