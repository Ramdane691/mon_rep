var searchData=
[
  ['pixel_19',['Pixel',['../structPixel.html',1,'']]]
];
