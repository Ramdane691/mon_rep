# Name Module Image

## Description

Ce projet est un module informatique, dévellopé en LIFAPCD à l'université Claude Bernard Lyon 1 en langage C++. Le but de ce module est d'afficher une image représentant le logo des jeux Olympiques


## Installation
Pour pouvoir compiler et executer ce module, il faut installer les bibliotheque sdl en tapant dans un terminal linux la commande sudo apt-get install libsdl2-dev libsdl2-image-dev libsdl2-ttf-dev libsdl2-mixer-dev
On peut egelement les trouver dans le sous repertoire extern/

## Organisation
Le répertoire /p2103034_p2002623_p2105694 de ce module image possede plusieurs sous répertoire:
- /bin contient les executables.
- /src contient les fichiers sources (.h et .cpp).
- /obj contient les fichiers objets (.o).
- /data contient les images crées par exemple,sauvées ou encore lues
- /doc contient la documentation Doxygen.
- /extern contient les bibliotheques sdl

Mais également deux fichiers:
- readme.md un fichier texte décrivant et expliquant la structure du projet
- Un fichier Makefile qui compile le code


Dans le sous répertoire /bin, on retrouve:
- bin/exemple exécute le code générant les images en sortie (i.e. exécute mainExemple.cpp)
- bin/test appelle la fonction testRegression de la classe Image (test de non-régression qui vérifie toute les fonction de la classe image) et affiche les tests effectués à l’écran (i.e. exécute mainTest.cpp)
- bin/affichage fait l’affichage de l’image dans une fenêtre SDL avec zoom/dézoom (i.e. exécute mainAffichage.cpp)


Dans le sous répertoire /src,on retrouve les fichiers:
-  Pixel.h et Pixel.cpp : Définissent la classe Pixel pour représenter les pixels d'une image.
-  Image.h et Image.cpp : Implémentente la classe Image pour la manipulation d'images.
-  ImageViewer.h et ImageViewer.cpp : Contiennent la classe ImageViewer pour visualiser des images avec SDL.
-  ImageView.h et ImageView.cpp : Implémentente la classe ImageView pour afficher des images avec SDL.
-  mainExemple.cpp : : Fournit un exemple d'utilisation de la librairie avec des fonctionnalités spécifiques.
-  mainAffichage.cpp : Contient le code principal pour afficher une image.
-  mainTest.cpp : Inclut des tests unitaires pour assurer la robustesse de la librairie.
-  mainAffichageAlternatif.cpp : Propose une alternative pour afficher une image avec des fonctionnalités différentes.


Dans le sous répertoire /doc, on retrouve:
- doc/doxyfile est le fichier de configuration de doxygen
- doc/html/index.html est la page d’entrée de la documentation, générée avec doxygen

## Compilation 

Le module image s'execute sous linux, dans le répertoire racine avec les commandes suivante:
-  make pour lancer la compilation 

# Exécution

Pour pouvoir exécuter  les programmes suivants, il est nécessaire de s'assurer que tout les fichiers utilisées par ces programmes sont dans le répertoire /data:

- ./bin/exemple pour executer le programme d'exemple qui génére des images de sorties
- ./bin/test pour tester la non-régression de la classe Image
- ./bin/affichage pour afficher l'image dans une fenetre SDL

## Usage

Utilisez généreusement des exemples et montrez le résultat attendu si vous le pouvez. Il est utile d'avoir en ligne le plus petit exemple d'utilisation que vous pouvez démontrer,



## Support
Pour tout soucis concernant l'execution de ce projet, veuillez contactez une des 3 adresses mails fournis dans la rubrique  ## Auteurs



## Auteurs
Crée par:

## License
contact: 











